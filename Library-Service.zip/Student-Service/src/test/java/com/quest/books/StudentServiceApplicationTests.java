package com.quest.books;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.quest.student.entity.Student;
import com.quest.student.repository.StudentRepository;

@SpringBootTest
class StudentServiceApplicationTests {
     
	@Autowired
	StudentRepository studentRepository;
	
	@Test
	public void savetudenttest() {
		
		Student student = new Student();
		student.setStudentId(11l);
		student.setStudentName("Ankit");
		student.setRollNumber(111);
		student.setEmailId("ankit@gamil.com");
		studentRepository.save(student);
		assertNotNull(studentRepository.findById(1l).get());
	}

}
