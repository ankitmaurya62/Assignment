package com.quest.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quest.student.entity.Student;
import com.quest.student.service.StudentService;

/*
 * Spring 4.0 introduced the @RestController annotation 
 * in order to simplify the creation of RESTful web services.
 *  It's a convenient annotation that combines @Controller and @ResponseBody,
 *   which eliminates the need to annotate every request handling method of the 
 *   controller class with the @ResponseBody annotation.
 */

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;


	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}

	//build save Student API's
	@PostMapping("/savestudent")
	public ResponseEntity<Student>addstudent(@RequestBody Student student){
		return new ResponseEntity<Student>(studentService.savestudent(student), HttpStatus.CREATED);


	}

	//build get all Student API's
	@GetMapping("/getallstudents")

	public List<Student> getAllStudents(){
		return studentService.getAllStudents();



	}


	//build get StudentById API's
	@GetMapping("/getbyid/{id}")
	public ResponseEntity<Student> getStuntById(@PathVariable("id") long studentId){
		return new ResponseEntity<Student>(studentService.getStudentById(studentId),HttpStatus.OK);

	}


	//build UpdateStudentById API's
	@PutMapping("/updatebyid/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable("id") long studentId, @RequestBody Student student){
		return new ResponseEntity<Student>(studentService.updateStudent(student, studentId),HttpStatus.OK);


	}


	//build DeleteStudentById API's
	@DeleteMapping("/deletebyid/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable("id") long studentId){

		studentService.deleteStudent(studentId);
		return new ResponseEntity<String>("Student deleted successfully!!", HttpStatus.OK);

	}
}
