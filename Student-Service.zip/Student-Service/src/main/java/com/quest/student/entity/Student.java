package com.quest.student.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * It contains dependencies for Freemaker, Spring Data JPA, and H2 database. 
 * When Spring Boot finds Freemaker and H2 in the pom. ... 
 * The @Entity annotation specifies that the class is an entity and is mapped to a database table. 
 * The @Table annotation specifies the name of the database table to be used for mapping
 * */

@Entity
@Table(name = "student")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)


	@Column(name="student_id")
	private Long studentId;

	@Column(name="student_name")
	private String studentName;

	@Column(name="email_id")
	private String emailId;

	@Column(name="roll_Number")
	private float rollNumber;


}